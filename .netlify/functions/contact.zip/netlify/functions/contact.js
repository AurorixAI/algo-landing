"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/contact.ts
var contact_exports = {};
__export(contact_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(contact_exports);
var CONTACT_EMAIL = process.env.CONTACT_EMAIL || "aurorixai@gmail.com";
var RESEND_API_KEY = process.env.RESEND_API_KEY;
var sanitize = (s) => s.replace(
  /[<>&"']/g,
  (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&#39;" })[c] || c
);
var handler = async (event, _ctx) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }
  const { name, email, message, type } = body;
  if (!name || typeof name !== "string" || name.length > 200) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid name" }) };
  }
  if (!email || typeof email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 320) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid email" }) };
  }
  if (message && (typeof message !== "string" || message.length > 2e3)) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid message" }) };
  }
  if (!type || !["demo", "pitchDeck", "connect"].includes(type)) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid type" }) };
  }
  const typeLabels = {
    demo: "\u0414\u0435\u043C\u043E \u0434\u043B\u044F \u0448\u043A\u043E\u043B",
    pitchDeck: "\u0417\u0430\u043F\u0440\u043E\u0441 Pitch Deck",
    connect: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u0446\u0435\u043D\u0442\u0440\u0430"
  };
  const htmlBody = `
    <h2>\u041D\u043E\u0432\u0430\u044F \u0437\u0430\u044F\u0432\u043A\u0430 \u0441 \u043B\u0435\u043D\u0434\u0438\u043D\u0433\u0430 ALGO</h2>
    <table style="border-collapse:collapse;width:100%;max-width:500px">
      <tr><td style="padding:8px;border:1px solid #e2e8f0;font-weight:bold">\u0422\u0438\u043F</td><td style="padding:8px;border:1px solid #e2e8f0">${sanitize(typeLabels[type] || type)}</td></tr>
      <tr><td style="padding:8px;border:1px solid #e2e8f0;font-weight:bold">\u0418\u043C\u044F</td><td style="padding:8px;border:1px solid #e2e8f0">${sanitize(name)}</td></tr>
      <tr><td style="padding:8px;border:1px solid #e2e8f0;font-weight:bold">Email</td><td style="padding:8px;border:1px solid #e2e8f0">${sanitize(email)}</td></tr>
      <tr><td style="padding:8px;border:1px solid #e2e8f0;font-weight:bold">\u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435</td><td style="padding:8px;border:1px solid #e2e8f0">${message ? sanitize(message) : "\u2014"}</td></tr>
    </table>
  `;
  if (!RESEND_API_KEY) {
    console.log("[contact] No RESEND_API_KEY. Logged:", { name, email, type, message });
    return {
      statusCode: 200,
      body: JSON.stringify({ ok: true, note: "Logged (no API key)" })
    };
  }
  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`
      },
      body: JSON.stringify({
        from: "ALGO Landing <onboarding@resend.dev>",
        to: [CONTACT_EMAIL],
        reply_to: email,
        subject: `[ALGO] ${typeLabels[type] || type} \u2014 ${name}`,
        html: htmlBody
      })
    });
    if (!response.ok) {
      const err = await response.text();
      console.error("[contact] Resend error:", err);
      return { statusCode: 502, body: JSON.stringify({ error: "Email delivery failed" }) };
    }
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ok: true })
    };
  } catch (err) {
    console.error("[contact] Unexpected error:", err);
    return { statusCode: 500, body: JSON.stringify({ error: "Internal server error" }) };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
